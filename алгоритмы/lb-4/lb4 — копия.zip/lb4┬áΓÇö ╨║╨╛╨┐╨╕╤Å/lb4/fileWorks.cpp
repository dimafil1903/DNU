//
//  fileWorks.cpp
//  lb4
//
//  Created by Дима Филипенко on 21.05.2020.
//  Copyright © 2020 Дима Филипенко. All rights reserved.
//

#include "fileWorks.hpp"
#include <fstream>
#include <iostream>
using namespace std;

   
int fout_rand(char *Name,int *arr,int size,int min,int max){
 
    int buf;
    ofstream fout;            // зв’язок з потоком виводу
    fout.open(Name);    // відкриття файлу
    if (!fout.is_open()) {
        cout << "Файл не може бути відкрито!\n";
        return 1;
    }    // якщо файл не відкрито

    
 srand(time(0));
      
    for (int i=0; i<size;i++){
         buf = rand()%(max-min + 1) + min;
              fout << buf << " ";
    }
           fout<<endl;
    
    fout.close();
    return 0;
}
int fout(char *Name,int *arr,int size){

    ofstream fout;            // зв’язок з потоком виводу
    fout.open(Name);    // відкриття файлу
    if (!fout.is_open()) {
        cout << "Файл не може бути відкрито!\n";
        return 1;
    }    // якщо файл не відкрито

    
 
      
    for (int i=0; i<size;i++){
        
              fout << arr[i] << " ";
    }
           fout<<endl;
    
    fout.close();
    return 0;
}
int fin(char *Name,int *arr,int size){
    
    ifstream fin;            // зв’язок з потоком вводу
    fin.open(Name);     // відкриття файлу
    if (!fin.is_open()){
        cout << " Файл не може бути відкрито!\n";
          return 1;
    }     // якщо файл не відкрито

    
    for (int i=0; i<size; i++)
    {     fin >> arr[i];
              //  cout << arr[i] << " ";
        
    }
    cout << endl;
    
    fin.close();
    return 0;

}
