//
//  fileWorks.hpp
//  lb4
//
//  Created by Дима Филипенко on 21.05.2020.
//  Copyright © 2020 Дима Филипенко. All rights reserved.
//

#ifndef fileWorks_hpp
#define fileWorks_hpp

#include <stdio.h>

int fout_rand(char *Name,int *arr,int size,int min,int max);
int fout(char *Name,int *arr,int size);
int fin(char *Name,int *arr,int size);
#endif /* fileWorks_hpp */
