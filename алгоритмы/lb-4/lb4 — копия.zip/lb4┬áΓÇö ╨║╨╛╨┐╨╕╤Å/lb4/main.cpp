//
//  main.cpp
//  lb4
//
//  Created by Дима Филипенко on 21.05.2020.
//  Copyright © 2020 Дима Филипенко. All rights reserved.
//

#include <iostream>
#include "fileWorks.hpp"
#include "sorts.hpp"
using namespace std;
using namespace std::chrono;

const int size=100;
bool filled=false;

int checkMinMax(int min,int max){
    if(min>max){
        cout<<"Что-то пошло не так"<<endl;
        return 1;
    }
    return 0;
}

void filledMsg(){
        cout<<"Массив не заполнен!"<<endl;
}

int fillArray(int *array,int *n){
    
    int max,min;
    char name[]={"data.txt"};
    if(*n==0){
              cout<<"size of arr=";cin>>*n;
    }

    do{
        cout<<"min=";cin>>min;
        cout<<"max=";cin>>max;
    }while (checkMinMax(min,max)==1);
    cout<<"файл "<<name<<" заполнен случайными значениями от "<<min<<" до "<<max<<endl;

    fout_rand(name, array,*n,min,max);
    filled=true;
    return 0;
}

int countingSortOutput(int n){
    
    if(!filled){
        filledMsg();
          return 1;
    }
      
    
    char name[]={"data.txt"};
    int *array=new int [n];
    int *B=new int[n];
    int *C=new int[n];
    
    fin(name, array, n);
   
    
    auto start = high_resolution_clock::now();
    countSort(array,B,C, n);
    auto stop = high_resolution_clock::now();
    
    fout(name, array, n);
    
    auto duration = duration_cast<microseconds>(stop - start);
    cout<<"2 Выполнено за "<<duration.count()<<" микросекунд"<<endl;
    return 0;
}
int exchangeSortOutput(int n,bool asc){
    int *array=new int[n];
     if(!filled){
          filledMsg();
            return 1;
      }
    char name[]={"data.txt"};
    
    fin(name, array, n);
    
    if(asc){
        auto start = high_resolution_clock::now();
        exchangeSort(array,n);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        cout<<"3 Выполнено за "<<duration.count()<<" микросекунд"<<endl;
    }else{
            exchangeSortDesc(array,n);
    }
    fout(name, array, n);
    return 0;
}
int heapSortOutput(int n){
       int *array=new int[n];
     if(!filled){
          filledMsg();
            return 1;
      }
    char name[]={"data.txt"};
    
    fin(name, array, n);
    
    auto start = high_resolution_clock::now();
    heapSort(array,n);
    auto stop = high_resolution_clock::now();

     
    fout(name, array, n);
    
    auto duration = duration_cast<microseconds>(stop - start);
    cout<<"4 Выполнено за "<<duration.count()<<" микросекунд"<<endl;
    return 0;
}
void timeTest1(int n){
    char name[]={"data.txt"};
    char nameOutput[]={"NotSortedData.txt"};
    int *array=new int [n];
    int *notSortedarray=new int [n];
//    int *B=new int[n];
//    int *C=new int[n];
    cout<<"Данные для массива с "<<n<<" элементов "<<endl;
    fillArray(array,&n);
    cout<<"Данные среднего случая"<<endl;
    fin(name, notSortedarray, n);
    fin(name, array, n);
    fout(nameOutput, array, n);
    fout(name, array, n);
    countingSortOutput(n);
    fin(nameOutput, array, n);
    exchangeSortOutput(n,true);
    fin(nameOutput, array, n);
    heapSortOutput(n);
    fin(nameOutput, array, n);
    cout<<"Данные лучшего случая"<<endl;
    countingSortOutput(n);
    exchangeSortOutput(n,true);
    heapSortOutput(n);
    cout<<"\nДанные худшего случая"<<endl;
    exchangeSortOutput(n,false);
    countingSortOutput(n);
    exchangeSortOutput(n,false);
    exchangeSortOutput(n,true);
    exchangeSortOutput(n,false);
    heapSortOutput(n);
}

int main(int argc, const char * argv[]) {
    int array[size];
    int k;
    int n=0;
    do{
        cout<<"1.Заполнить массив"<<endl;
        cout<<"2.Сортировка Подсчетом"<<endl;
        cout<<"3.Сортировка Пузырьком"<<endl;
        cout<<"4.Пирамидальная сортировка"<<endl;
        cout<<"5.Сортировка в обратном порядке (Пузырьком)"<<endl;
        cout<<"6.Замер времени для таблички"<<endl;
        cin>>k;

        if(k==1)
            fillArray(array,&n);
        else if(k==2)
            countingSortOutput(n);
        else if(k==3)
            exchangeSortOutput(n,true);
        else if(k==4)
            heapSortOutput(n);
        else if(k==5)
            exchangeSortOutput(n,false);
        else if(k==6)
            for (int i=0; i<=6; i++) {
                if(i==0)
                    n=100;
                if(i==1)
                    n=500;
                if(i==2)
                    n=1000;
                if(i==3)
                    n=5000;
                if(i==4)
                    n=10000;
                if(i==5)
                    n=30000;
                if(i==6)
                    n=50000;
                    timeTest1(n);
               
            }
   


    }while (k!=0);

}
