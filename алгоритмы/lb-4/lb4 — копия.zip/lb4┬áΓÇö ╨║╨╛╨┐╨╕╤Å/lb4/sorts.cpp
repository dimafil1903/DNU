//
//  sorts.cpp
//  lb4
//
//  Created by Дима Филипенко on 21.05.2020.
//  Copyright © 2020 Дима Филипенко. All rights reserved.
//

#include "sorts.hpp"
#include <iostream>
using namespace std;

void countSort(int array[], int output[],int count[],int size) {

  int max = array[0];
    
  for (int i = 1; i < size; i++) {
    if (array[i] > max)
      max = array[i];
  }

  for (int i = 0; i <= max; ++i) {
    count[i] = 0;
     
  }

  for (int i = 0; i < size; i++) {
    count[array[i]]=count[array[i]]+1;
  }
  
  for (int i = 1; i <= max; i++) {
    count[i] =count[i]+ count[i - 1];
  }
 
  for (int i = size - 1; i >= 0; i--) {
    output[count[array[i]] - 1] = array[i];
    count[array[i]]=count[array[i]]-1;
  }

  for (int i = 0; i < size; i++) {
    array[i] = output[i];
      
  }
}

void exchangeSort(int *array,int length){
    int i, j;
    int temp;
    int flag;
    for(i = 0; i < (length -1); i++)
    {
        flag=0;
        for (j=(i + 1); j < length; j++)
        {
            if (array[i] > array[j])
            {
                temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                flag=1;
            }
        }
        if (flag==0)
            break;
    }
}
void exchangeSortDesc(int *array,int length){
    int i, j;
    int temp;
    int flag;
    for(i = 0; i < (length -1); i++)
    {
        flag=0;
        for (j=(i + 1); j < length; j++)
        {
            if (array[i] <= array[j])
            {
                temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                flag=1;
            }
        }
        if (flag==0)
            break;
    }
}
void heapify(int arr[], int n, int i)
{
    int largest = i;

    int l = 2*i + 1;
    int r = 2*i + 2;

 
    if (l < n && arr[l] > arr[largest])
        largest = l;

   
    if (r < n && arr[r] > arr[largest])
        largest = r;

    if (largest != i)
    {
        swap(arr[i], arr[largest]);

        heapify(arr, n, largest);
    }
}


void heapSort(int *arr, int n)
{

    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);


    for (int i=n-1; i>=0; i--)
    {
       
        swap(arr[0], arr[i]);

       
        heapify(arr, i, 0);
    }
}
