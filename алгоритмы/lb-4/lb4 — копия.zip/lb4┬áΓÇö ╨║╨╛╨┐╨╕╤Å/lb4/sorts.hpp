//
//  sorts.hpp
//  lb4
//
//  Created by Дима Филипенко on 21.05.2020.
//  Copyright © 2020 Дима Филипенко. All rights reserved.
//

#ifndef sorts_hpp
#define sorts_hpp

#include <stdio.h>
void countSort(int *array, int *output,int *count,int size);
void exchangeSort(int *array,int length);
void exchangeSortDesc(int *array,int length);
void heapSort(int *array, int size);
#endif /* sorts_hpp */
